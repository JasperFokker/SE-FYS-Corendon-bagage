/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.fys.corendon.bagage;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.application.Application;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author jimmy
 */
public class Scherm1 extends Application
{
    @Override
    public void start(Stage primaryStage)
    {
        returnScherm();
    }
    
    public static GridPane returnScherm() {
        GridPane scherm1 = new GridPane();
        
        
        //DOE HIER JE SHIT
        Label label = new Label();
        label.setText("hoi");

        scherm1.setPrefSize(400, 200);
        Button btn = new Button();
        btn.setPrefSize(300, 20);
        
        scherm1.add(label, 200, 100);
        scherm1.add(btn, 0, 0);
        
        return scherm1;
    }
}
