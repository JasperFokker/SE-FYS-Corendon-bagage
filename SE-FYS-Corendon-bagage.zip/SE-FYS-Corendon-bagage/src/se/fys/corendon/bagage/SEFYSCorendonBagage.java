package se.fys.corendon.bagage;

import java.awt.Button;
import java.awt.Label;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author jimmy
 */
public class SEFYSCorendonBagage extends Application
{
    @Override
    public void start(Stage primaryStage)
    {
        GridPane root = Scherm1.returnScherm();
        
        Scene scene = new Scene(root);
        
        primaryStage.setTitle("Main Screen");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args)
    {
        launch(args);
    }    
}
